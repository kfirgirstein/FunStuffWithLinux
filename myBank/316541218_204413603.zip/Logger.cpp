/*
 * Logger.cpp
 *
 *  Created on: May 17, 2020
 *      Author: os
 */

#include "Logger.h"

//initializing static variables
const std::string Logger::_filename = "log.txt";
Logger* Logger::_instace = NULL;


Logger::Logger(void)
{
	this->_fout.open(Logger::_filename.c_str(),
			std::ios::out | std::ios::app);
	if(!this->_fout.is_open())
	{
		throw std::runtime_error("\n log.txt initializing has failed for logger \n");
	}
	if (pthread_mutex_init(&this->_lock, NULL) != 0)
	{
		throw std::runtime_error("\n mutex initializing has failed for logger\n");
	}

}
Logger::~Logger(void)
{
	this->_fout.close();
	pthread_mutex_destroy(&_lock);
}

/*****************************/
//--- Singleton Functions ---//
/*****************************/
Logger* Logger::GetLogger()
{
	if (_instace == NULL)
	{
		try {
		_instace = new Logger();

		} catch (std::exception& e) {
			perror(e.what());

		}
	}
	return _instace;
}
void Logger::ReturnLogger(void)
{
	delete _instace;
}


/*****************************/
//----- Print Functions -----//
/*****************************/
void Logger::write(const std::string& message)
{
	pthread_mutex_lock(&_lock);
	this->_fout << message << std::endl;
	pthread_mutex_unlock(&_lock);
}

// https://stackoverflow.com/questions/38224079/how-to-create-a-wrapper-on-printf
void Logger::write(const char* format, ...)
{
	char* sMessage = NULL;
	int nLength = 0;
	va_list args;
	va_start(args, format);
	nLength = vsnprintf(NULL, 0, format, args) + 1;
	sMessage = new char[nLength];
	vsnprintf(sMessage, nLength, format, args);
	pthread_mutex_lock(&_lock);
	this->_fout << sMessage << std::endl;
	pthread_mutex_unlock(&_lock);
	va_end(args);
	delete[] sMessage;
}

Logger& Logger::operator <<(const std::string& message)
{
	pthread_mutex_lock(&_lock);
	this->_fout << message << std::endl;
	pthread_mutex_unlock(&_lock);
	return *this;
}

