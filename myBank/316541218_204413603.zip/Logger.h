/*
 * Logger.h
 *
 *  Created on: May 17, 2020
 *      Author: os
 */

#ifndef LOGGER_H_
#define LOGGER_H_
#include <iostream>
#include <fstream>
#include <cstdarg>
#include <string>
#include <stdarg.h>
#include <pthread.h>
#include <exception>

#define LOG Logger::GetLogger() //Lazy initialization 

/*************************************************/
 //-- Class that defines a Synchronized Logger --//
 //-- implemented as Singleton Design Pattern  --//
/*************************************************/
class Logger
{

public:

	//----- Singleton Methods-----//
	static Logger * GetLogger();
	static void ReturnLogger();


	//----- Print Functions -----//
	Logger& operator<<(const std::string&);
	void write(const std::string& message);
	void write(const char * format, ...);

private:
	Logger();
	~Logger();
	//----- Singleton Variables-----//
	static uint _instanceNumber;
	static Logger* _instace;
	static const std::string _filename;
	std::ofstream _fout;

	//----- Locker -----//
	pthread_mutex_t _lock;

};
#endif /* LOGGER_H_ */
